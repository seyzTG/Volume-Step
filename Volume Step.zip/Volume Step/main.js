// Скрипт в контексте страницы: перехватывает ↑/↓ и меняет громкость плеера YouTube
(() => {
  if (window.__ytVolStepLoaded) return;
  window.__ytVolStepLoaded = true;

  const ds = document.documentElement.dataset;
  const getStep = () => {
    const n = parseInt(ds.ytVolStep, 10);
    return n >= 1 && n <= 100 ? n : 1;
  };

  let hud = null;
  let hudTimer = null;

  function showHud(player, value) {
    if (ds.ytVolHud === '0') return;
    if (!hud || !player.contains(hud)) {
      hud = document.createElement('div');
      hud.style.cssText = [
        'position:absolute', 'top:10%', 'left:50%', 'transform:translateX(-50%)',
        'min-width:84px', 'padding:8px 14px 10px', 'background:rgba(15,15,15,.78)',
        'color:#fff', 'font:300 22px/1 Roboto,Arial,sans-serif', 'text-align:center',
        'border-radius:6px', 'z-index:2000', 'pointer-events:none', 'transition:opacity .2s'
      ].join(';');
      const num = document.createElement('div');
      const bar = document.createElement('div');
      bar.style.cssText = 'margin-top:8px;height:2px;background:rgba(255,255,255,.25);border-radius:1px;overflow:hidden';
      const fill = document.createElement('div');
      fill.style.cssText = 'height:100%;background:#fff;width:0';
      bar.appendChild(fill);
      hud.append(num, bar);
      hud._num = num; hud._fill = fill;
      player.appendChild(hud);
    }
    hud._num.textContent = value + '%';
    hud._fill.style.width = value + '%';
    hud.style.opacity = '1';
    clearTimeout(hudTimer);
    hudTimer = setTimeout(() => { hud.style.opacity = '0'; }, 800);
  }

  window.addEventListener('keydown', (e) => {
    if (ds.ytVolEnabled === '0') return;
    if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
    if (e.ctrlKey || e.altKey || e.metaKey || e.shiftKey) return;

    const player = document.getElementById('movie_player');
    if (!player) return;

    const t = e.target;
    if (!(t instanceof Element)) return;
    if (t.closest('input, textarea, select, [contenteditable="true"]')) return;

    // перехватываем, если фокус в плеере ИЛИ курсор мыши над плеером
    const inPlayer = player.contains(t) || player.matches(':hover');
    if (!inPlayer) return;

    e.preventDefault();
    e.stopImmediatePropagation();

    const step = getStep();
    const delta = e.key === 'ArrowUp' ? step : -step;
    const video = player.querySelector('video');

    if (typeof player.setVolume === 'function') {
      const muted = typeof player.isMuted === 'function' && player.isMuted();
      const current = muted ? 0 : player.getVolume();
      const next = Math.max(0, Math.min(100, current + delta));
      if (next > 0 && muted) player.unMute();
      player.setVolume(next);
      showHud(player, next);
    } else if (video) {
      // запасной вариант, если API плеера недоступно
      const next = Math.max(0, Math.min(100, Math.round(video.volume * 100) + delta));
      video.muted = false;
      video.volume = next / 100;
      showHud(player, next);
    }
  }, true);
})();
