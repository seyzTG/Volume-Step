const $ = (id) => document.getElementById(id);
const DEFAULTS = { enabled: true, step: 1, hud: true };
const clamp = (v) => Math.max(1, Math.min(100, parseInt(v, 10) || 1));

let state = { ...DEFAULTS };

$('ver').textContent = 'v' + chrome.runtime.getManifest().version;

function render() {
  $('enabled').checked = state.enabled;
  $('hud').checked = state.hud;
  if (document.activeElement !== $('num')) $('num').value = state.step;
  $('range').value = Math.min(20, state.step);
  $('stepBox').classList.toggle('off', !state.enabled);
  document.querySelectorAll('#presets button').forEach((b) =>
    b.classList.toggle('active', Number(b.dataset.v) === state.step));
}

function save(patch) {
  state = { ...state, ...patch };
  chrome.storage.sync.set(state);
  render();
}

chrome.storage.sync.get(DEFAULTS, (s) => { state = s; render(); });

$('enabled').addEventListener('change', (e) => save({ enabled: e.target.checked }));
$('hud').addEventListener('change', (e) => save({ hud: e.target.checked }));
$('range').addEventListener('input', (e) => save({ step: clamp(e.target.value) }));
$('num').addEventListener('input', (e) => { if (e.target.value !== '') save({ step: clamp(e.target.value) }); });
$('num').addEventListener('blur', () => { $('num').value = state.step; });
$('minus').addEventListener('click', () => save({ step: clamp(state.step - 1) }));
$('plus').addEventListener('click', () => save({ step: clamp(state.step + 1) }));
$('presets').addEventListener('click', (e) => {
  const v = e.target.dataset && e.target.dataset.v;
  if (v) save({ step: Number(v) });
});
$('open').addEventListener('click', () => chrome.tabs.create({ url: 'https://www.youtube.com/' }));
