// Изолированный скрипт: передаёт настройки в страницу и подключает main.js в контекст страницы
const ds = document.documentElement.dataset;

const apply = ({ enabled, step, hud }) => {
  ds.ytVolEnabled = enabled ? '1' : '0';
  ds.ytVolStep = String(step);
  ds.ytVolHud = hud ? '1' : '0';
};

const DEFAULTS = { enabled: true, step: 1, hud: true };

apply(DEFAULTS);
chrome.storage.sync.get(DEFAULTS, apply);
chrome.storage.onChanged.addListener(() => chrome.storage.sync.get(DEFAULTS, apply));

const s = document.createElement('script');
s.src = chrome.runtime.getURL('main.js');
s.onload = () => s.remove();
(document.head || document.documentElement).appendChild(s);
